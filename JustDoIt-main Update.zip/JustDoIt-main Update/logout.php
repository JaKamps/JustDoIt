<?php
require_once 'functions.php';

session_destroy();
header("location: index.html?error=loggedout");
exit();