<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div class="navbar">
        <div class="Home"><a href="index.html">Home</a></div>
        <div class="Lijst"><a href="Lijsten.html" class="navdrop">Lijsten</a></div>
        <div class="Account"><a href="Accounts.html">Account</a></div>
      
    </div>
</header>

<div class="Welkom">

    <div class="WelkomBorder">
    <h1 class="WelkomTekst">Welkom op onze website!</h1>
    </div>

    <div class="SubTekst">
    <h3 >Heb jij moeite met je activiteiten bij houden? <br>Wij hebben een site gemaakt waar je To do lijsten kan maken. Je hoeft alleen een account aan te maken en je kan beginnen!</h3>
    </div>

</div>

</body>
</html>